const logger = require('../config/logger');

const dropCollections = async (mongoose) => {
  const collections = Object.keys(mongoose.connection.collections);
  for (const collectionName of collections) {
    logger.warn(collectionName);
    const collection = mongoose.connection.collections[collectionName];
    try {
      await collection.deleteMany();
    } catch (error) {
      logger.warn(`Error dropping collection ${collectionName}: ${error}`);
    } finally {
    }
  }
  logger.info('wipe done');
};

module.exports = dropCollections;
