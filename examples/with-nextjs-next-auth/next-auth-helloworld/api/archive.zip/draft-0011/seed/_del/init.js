const logger = require('../config/logger');

module.exports = async (mongoose) => {
  logger.info('init seed db');

  await require('./wipe')(mongoose);

  require('./user');
  require('./status');
  require('./store');

  logger.info('init seed db done');
};
