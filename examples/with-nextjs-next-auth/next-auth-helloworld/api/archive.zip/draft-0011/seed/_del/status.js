const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const faker = require('faker');
const Status = require('../../src/models/status.model');

const password = 'password1';
const salt = bcrypt.genSaltSync(8);
const hashedPassword = bcrypt.hashSync(password, salt);

// sample data
// [
//   {
//     "id": 5,
//     "text": "Cancelled"
//   }
// ]

const insertStatuses = async (statuses) => {
  await Status.insertMany(statuses);
};

(async () => {
  await insertStatuses([
    {
      _id: mongoose.Types.ObjectId(1),
      text: 'Cancelled',
    },
    {
      _id: mongoose.Types.ObjectId(2),
      text: 'In Progress',
    },
    {
      _id: mongoose.Types.ObjectId(3),
      text: 'Complete',
    },
    {
      _id: mongoose.Types.ObjectId(4),
      text: 'Pending',
    },
    {
      _id: mongoose.Types.ObjectId(5),
      text: 'Blocked',
    },
  ]);
})();
