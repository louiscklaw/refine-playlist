const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const faker = require('faker');
const Store = require('../../src/models/Store.model');

const password = 'password1';
const salt = bcrypt.genSaltSync(8);
const hashedPassword = bcrypt.hashSync(password, salt);

// sample data
// [
//   {
//     "id": 1,
//     "title": "Camryn Ridge",
//     "email": "Bridget19@gmail.com",
//     "gsm": "(132) 035-3190",
//     "isActive": false,
//     "createdAt": "2023-11-26T12:49:17.153Z",
//     "address": {
//       "text": "11060 Adrain Lane, Brooklyn, NY 11686",
//       "coordinate": [
//         "40.67383279814411",
//         "-73.97836946535837"
//       ]
//     },
//     "products_id": [1,2,3,4,5]
//   }
// ]

const insertStores = async (Stores) => {
  await Store.insertMany(Stores);
};

module.exports = async () => {
  await insertStores([
    {
      _id: mongoose.Types.ObjectId(1),
      title: 'Camryn Ridge',
      email: 'Bridget19@gmail.com',
      gsm: '(132) 035-3190',
      isActive: false,
      createdAt: new Date(),
      address: {
        text: '11060 Adrain Lane, Brooklyn, NY 11686',
        coordinate: [40.67383279814411, -73.97836946535837],
      },
      products_id: [1, 2, 3, 4, 5],
    },
  ]);
};
