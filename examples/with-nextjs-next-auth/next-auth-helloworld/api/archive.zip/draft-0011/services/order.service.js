const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');

// sample data
// [
//   {
//     "id": 1,
//     "user_rel": "a0357223-48f9-4934-a854-37c426c60d12",
//     "amount": 21,
//     "createdAt": "2024-06-28T16:59:14.876Z",
//     "products_id": [ 38, 55 ],
//     "status_id": "a0357223-48f9-4934-a854-37c426c60d12",
//     "address_id": "a0357223-48f9-4934-a854-37c426c60d12",
//     "store_id": 15,
//     "courier_id": 63,
//     "events": [
//       {
//         "date": "2024-06-28T16:59:14.876Z",
//         "status": "Pending"
//       },
//       {
//         "date": "2024-06-28T17:01:14.876Z",
//         "status": "Ready"
//       },
//       {
//         "date": "2024-06-28T17:03:14.876Z",
//         "status": "On The Way"
//       },
//       {
//         "date": "2024-06-28T17:04:14.876Z",
//         "status": "Cancelled"
//       }
//     ],
//     "orderNumber": 624806
//   }
// ]

const { Order } = require('../models');

/**
 * Create a order
 * @param {Object} orderBody
 * @returns {Promise<Order>}
 */
const createOrder = async (orderBody) => {
  return Order.create(orderBody);
};

/**
 * Query for orders
 * @param {Object} filter - Mongo filter
 * @param {Object} options - Query options
 * @param {string} [options.sortBy] - Sort option in the format: sortField:(desc|asc)
 * @param {number} [options.limit] - Maximum number of results per page (default = 10)
 * @param {number} [options.page] - Current page (default = 1)
 * @returns {Promise<QueryResult>}
 */
const queryOrders = async (filter, options) => {
  const orders = await Order.paginate(filter, options);
  return orders;
};

/**
 * Get order by id
 * @param {ObjectId} id
 * @returns {Promise<Order>}
 */
const getOrderById = async (id) => {
  return Order.findById(id);
};

/**
 * Update order by id
 * @param {ObjectId} orderId
 * @param {Object} updateBody
 * @returns {Promise<Order>}
 */
const updateOrderById = async (orderId, updateBody) => {
  const order = await getOrderById(orderId);
  if (!order) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Order not found');
  }
  Object.assign(order, updateBody);
  await order.save();
  return order;
};

/**
 * Delete order by id
 * @param {ObjectId} orderId
 * @returns {Promise<Order>}
 */
const deleteOrderById = async (orderId) => {
  const order = await getOrderById(orderId);
  if (!order) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Order not found');
  }
  await order.remove();
  return order;
};

module.exports = {
  createOrder,
  queryOrders,
  getOrderById,
  updateOrderById,
  deleteOrderById,
};
