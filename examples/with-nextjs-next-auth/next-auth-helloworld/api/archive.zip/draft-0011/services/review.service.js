const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');

// sample data
// [
//   {
//     "id": 1,
//     "order_id": 622,
//     "user_id": 112,
//     "star": 4,
//     "createdAt": "2024-06-29T15:53:37.424Z",
//     "status": "pending",
//     "comment": [
//       "The box this comes in is 3 inch by 6 centimeter and weights 15 ounce!"
//     ]
//   }
// ]

const { Review } = require('../models');

/**
 * Create a review
 * @param {Object} reviewBody
 * @returns {Promise<Review>}
 */
const createReview = async (reviewBody) => {
  if (await Review.isCommentTaken(reviewBody.comment)) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Comment already taken');
  }
  return Review.create(reviewBody);
};

/**
 * Query for reviews
 * @param {Object} filter - Mongo filter
 * @param {Object} options - Query options
 * @param {string} [options.sortBy] - Sort option in the format: sortField:(desc|asc)
 * @param {number} [options.limit] - Maximum number of results per page (default = 10)
 * @param {number} [options.page] - Current page (default = 1)
 * @returns {Promise<QueryResult>}
 */
const queryReviews = async (filter, options) => {
  const reviews = await Review.paginate(filter, options);
  return reviews;
};

/**
 * Get review by id
 * @param {ObjectId} id
 * @returns {Promise<Review>}
 */
const getReviewById = async (id) => {
  return Review.findById(id);
};

/**
 * Get review by comment
 * @param {string} comment
 * @returns {Promise<Review>}
 */
const getReviewByComment = async (comment) => {
  return Review.findOne({ comment });
};

/**
 * Update review by id
 * @param {ObjectId} reviewId
 * @param {Object} updateBody
 * @returns {Promise<Review>}
 */
const updateReviewById = async (reviewId, updateBody) => {
  const review = await getReviewById(reviewId);
  if (!review) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Review not found');
  }
  if (updateBody.comment && (await Review.isCommentTaken(updateBody.comment, reviewId))) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Comment already taken');
  }
  Object.assign(review, updateBody);
  await review.save();
  return review;
};

/**
 * Delete review by id
 * @param {ObjectId} reviewId
 * @returns {Promise<Review>}
 */
const deleteReviewById = async (reviewId) => {
  const review = await getReviewById(reviewId);
  if (!review) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Review not found');
  }
  await review.remove();
  return review;
};

module.exports = {
  createReview,
  queryReviews,
  getReviewById,
  getReviewByComment,
  updateReviewById,
  deleteReviewById,
};
