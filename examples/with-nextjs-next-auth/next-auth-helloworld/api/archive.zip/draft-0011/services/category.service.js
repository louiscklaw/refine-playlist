const httpStatus = require('http-status');
const { Category } = require('../models');
const ApiError = require('../utils/ApiError');

// sample data
// [
//   {
//     "id": 1,
//     "title": "🍟 Starters",
//     "isActive": true
//   },
//   {
//     "id": 2,
//     "title": "🍝 Pastas",
//     "isActive": true
//   },
//   {
//     "id": 10,
//     "title": "☕ Hot Drinks",
//     "isActive": true
//   }
// ]

/**
 * Create a category
 * @param {Object} categoryBody
 * @returns {Promise<Status>}
 */
const createCategory = async (categoryBody) => {
  if (await Category.isTitleTaken(categoryBody.title)) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Title already taken');
  }
  return Category.create(categoryBody);
};

/**
 * Query for categories
 * @param {Object} filter - Mongo filter
 * @param {Object} options - Query options
 * @param {string} [options.sortBy] - Sort option in the format: sortField:(desc|asc)
 * @param {number} [options.limit] - Maximum number of results per page (default = 10)
 * @param {number} [options.page] - Current page (default = 1)
 * @returns {Promise<QueryResult>}
 */
const queryCategories = async (filter, options) => {
  const categories = await Category.paginate(filter, options);
  return categories;
};

/**
 * Get category by id
 * @param {ObjectId} id
 * @returns {Promise<Status>}
 */
const getCategoryById = async (id) => {
  return Category.findById(id);
};

/**
 * Get category by title
 * @param {string} title
 * @returns {Promise<Status>}
 */
const getCategoryByTitle = async (title) => {
  return Category.findOne({ title });
};

/**
 * Update category by id
 * @param {ObjectId} categoryId
 * @param {Object} updateBody
 * @returns {Promise<Status>}
 */
const updateCategoryById = async (categoryId, updateBody) => {
  const category = await getCategoryById(categoryId);
  if (!category) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Category not found');
  }
  if (updateBody.title && (await Category.isTitleTaken(updateBody.title, categoryId))) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Title already taken');
  }
  Object.assign(category, updateBody);
  await category.save();
  return category;
};

/**
 * Delete category by id
 * @param {ObjectId} categoryId
 * @returns {Promise<Status>}
 */
const deleteCategoryById = async (categoryId) => {
  const category = await getCategoryById(categoryId);
  if (!category) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Category not found');
  }
  await category.remove();
  return category;
};

module.exports = {
  createCategory,
  queryCategories,
  getCategoryById,
  getCategoryByTitle,
  updateCategoryById,
  deleteCategoryById,
};
