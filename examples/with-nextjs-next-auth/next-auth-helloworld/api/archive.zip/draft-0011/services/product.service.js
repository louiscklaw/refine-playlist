const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');

// sample data
// [
// {
//   "id": 67,
//   "name": "Garlic Bread",
//   "isActive": false,
//   "description": "Warm, buttery bread seasoned with garlic and herbs, toasted to perfection.",
//   "images": [ "5e982861-68ca-405e-941c-fcc9e160d70b" ],
//   "createdAt": "2024-04-04T04:18:23.076Z",
//   "price": 6,
//   "category_id": 1
// },
// {
//   "id": 67,
//   "name": "Garlic Bread",
//   "isActive": false,
//   "description": "Warm, buttery bread seasoned with garlic and herbs, toasted to perfection.",
//   "images": [ "5e982861-68ca-405e-941c-fcc9e160d70b" ],
//   "createdAt": "2024-04-04T04:18:23.076Z",
//   "price": 6,
//   "category_id": 1
// },
// ]

const { Product } = require('../models');

/**
 * Create a product
 * @param {Object} productBody
 * @returns {Promise<Product>}
 */
const createProduct = async (productBody) => {
  if (await Product.isNameTaken(productBody.name)) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Name already taken');
  }
  return Product.create(productBody);
};

/**
 * Query for products
 * @param {Object} filter - Mongo filter
 * @param {Object} options - Query options
 * @param {string} [options.sortBy] - Sort option in the format: sortField:(desc|asc)
 * @param {number} [options.limit] - Maximum number of results per page (default = 10)
 * @param {number} [options.page] - Current page (default = 1)
 * @returns {Promise<QueryResult>}
 */
const queryProducts = async (filter, options) => {
  const products = await Product.paginate(filter, options);
  return products;
};

/**
 * Get product by id
 * @param {ObjectId} id
 * @returns {Promise<Product>}
 */
const getProductById = async (id) => {
  return Product.findById(id);
};

/**
 * Get product by name
 * @param {string} name
 * @returns {Promise<Product>}
 */
const getProductByName = async (name) => {
  return Product.findOne({ name });
};

/**
 * Update product by id
 * @param {ObjectId} productId
 * @param {Object} updateBody
 * @returns {Promise<Product>}
 */
const updateProductById = async (productId, updateBody) => {
  const product = await getProductById(productId);
  if (!product) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Product not found');
  }
  if (updateBody.name && (await Product.isNameTaken(updateBody.name, productId))) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Name already taken');
  }
  Object.assign(product, updateBody);
  await product.save();
  return product;
};

/**
 * Delete product by id
 * @param {ObjectId} productId
 * @returns {Promise<Product>}
 */
const deleteProductById = async (productId) => {
  const product = await getProductById(productId);
  if (!product) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Product not found');
  }
  await product.remove();
  return product;
};

module.exports = {
  createProduct,
  queryProducts,
  getProductById,
  getProductByName,
  updateProductById,
  deleteProductById,
};
