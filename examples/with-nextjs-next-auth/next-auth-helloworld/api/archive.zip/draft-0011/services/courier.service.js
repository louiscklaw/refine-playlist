const httpStatus = require('http-status');
const ApiError = require('../utils/ApiError');

// sample data
// [
// {
//   "id": 1,
//   "name": "Stella Rolfson",
//   "email": "Beth.Baumbach@hotmail.com",
//   "gender": "Male",
//   "gsm": "(752) 945-0598",
//   "createdAt": "2023-09-06T06:18:35.744Z",
//   "accountNumber": 7088877265,
//   "licensePlate": "ZDZ 916",
//   "address": "11567 Mosciski Drive, Brooklyn, NY 11746",
//   "store_id": 9
//   "status_id": 3
//   "vehicle_id": 2,
//   "avatar_uid": "df24bc11-711e-4c16-987e-86b05ca6d5e4"
// }
// ]

const { Courier } = require('../models');

/**
 * Create a courier
 * @param {Object} courierBody
 * @returns {Promise<Courier>}
 */
const createCourier = async (courierBody) => {
  if (await Courier.isTextTaken(courierBody.name)) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Name already taken');
  }
  return Courier.create(courierBody);
};

/**
 * Query for couriers
 * @param {Object} filter - Mongo filter
 * @param {Object} options - Query options
 * @param {string} [options.sortBy] - Sort option in the format: sortField:(desc|asc)
 * @param {number} [options.limit] - Maximum number of results per page (default = 10)
 * @param {number} [options.page] - Current page (default = 1)
 * @returns {Promise<QueryResult>}
 */
const queryCouriers = async (filter, options) => {
  console.log('find me ?');
  const couriers = await Courier.paginate(filter, options);
  return couriers;
};
/**
 * Get courier by id
 * @param {ObjectId} id
 * @returns {Promise<Courier>}
 */
const getCourierById = async (id) => {
  return Courier.findById(id);
};

/**
 * Get courier by name
 * @param {string} name
 * @returns {Promise<Courier>}
 */
const getCourierByName = async (name) => {
  return Courier.findOne({ name });
};

/**
 * Update courier by id
 * @param {ObjectId} courierId
 * @param {Object} updateBody
 * @returns {Promise<Courier>}
 */
const updateCourierById = async (courierId, updateBody) => {
  const courier = await getCourierById(courierId);
  if (!courier) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Courier not found');
  }
  if (updateBody.name && (await Courier.isNameTaken(updateBody.name, courierId))) {
    throw new ApiError(httpStatus.BAD_REQUEST, 'Name already taken');
  }
  Object.assign(courier, updateBody);
  await courier.save();
  return courier;
};

/**
 * Delete courier by id
 * @param {ObjectId} courierId
 * @returns {Promise<Courier>}
 */
const deleteCourierById = async (courierId) => {
  const courier = await getCourierById(courierId);
  if (!courier) {
    throw new ApiError(httpStatus.NOT_FOUND, 'Courier not found');
  }
  await courier.remove();
  return courier;
};

module.exports = {
  createCourier,
  queryCouriers,
  getCourierById,
  getCourierByName,
  updateCourierById,
  deleteCourierById,
};
