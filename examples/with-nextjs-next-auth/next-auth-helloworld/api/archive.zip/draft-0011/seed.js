const mongoose = require('mongoose');
const app = require('./app');
const config = require('./config/config');
const logger = require('./config/logger');

const fs = require('fs');

const readSeedJson = (filename) => JSON.parse(fs.readFileSync(filename));

mongoose
  .connect(config.mongoose.url, config.mongoose.options)
  .then(async () => {
    logger.info('Connected to MongoDB');

    logger.info(config.mongoose.url, config.mongoose.options);

    const collections = Object.keys(mongoose.connection.collections);

    for (const collectionName of collections) {
      logger.warn(collectionName);
      const collection = mongoose.connection.collections[collectionName];
      try {
        await collection.deleteMany();
      } catch (error) {
        logger.warn(`Error dropping collection ${collectionName}: ${error}`);
      } finally {
      }
    }
  })
  .then(async () => {
    let coll_list = [
      'hello',
      'couriers',
      'categories',
      'courierstatuses',
      'orders',
      'orderstatuses',
      'products',
      'reviews',
      'status',
      'stores',
      'summaries',
      'trendingproducts',
      'vehicles',
      'users',
    ];

    for (let i = 0; i < coll_list.length; i++) {
      let coll_name = coll_list[i];
      console.log(`loading ${coll_name}`);

      if (coll_name == 'users') {
        let users_json = readSeedJson(`./src/seed/users.json`);
        let users_json_len = users_json.length;
        for (let i = 0; i < users_json_len; i++) {
          users_json[i]['email'] = `user${i + 1}@test.com`;
        }
        await mongoose.connection.collection(coll_name).insertMany(users_json);
      } else {
        await mongoose.connection.collection(coll_name).insertMany(readSeedJson(`./src/seed/${coll_name}.json`));
      }
    }
  });
